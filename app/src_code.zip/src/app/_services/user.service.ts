import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// TODO
const API_URL = 'https://labinfsoft.herokuapp.com/api/videos?limite=10&desde=0';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(private http: HttpClient) {}

  getContent(): Observable<any> {
    return this.http.get(API_URL + 'all', { responseType: 'json' });
  }
}
