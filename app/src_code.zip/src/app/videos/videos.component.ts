import { Component, OnInit, OnChanges, AfterViewInit } from '@angular/core';
import { TokenStorageService } from '../_services/token-storage.service';
import { UserService } from '../_services/user.service';

@Component({
  selector: 'app-videos',
  templateUrl: './videos.component.html',
  styleUrls: ['./videos.component.css'],
})
export class VideosComponent implements OnInit {
  currentUser: any;
  videoData: any;
  VIDEOS: Array<any> = [];

  constructor(
    private token: TokenStorageService,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.currentUser = this.token.getUser();
    // console.log(this.currentUser);

    if (Object.keys(this.currentUser).length === 0) {
      window.location.href = '/login';
    }

    this.userService.getContent().subscribe(
      (data) => {
        console.log(data);
        this.videoData = data;
        this.VIDEOS = data.productos;
        console.log(this.VIDEOS);
      },
      (err) => {
        console.log(err.error);
      }
    );
  }

  // ngAfterViewInit(): void {
  //   console.log('AFterViewInit');
  // }
}
